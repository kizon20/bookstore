<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Document</title>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css">
    <link rel="stylesheet" href="view/css/main.css">
     <link rel="stylesheet" href="../view/image/">


</head>
<body>
     <?php
                       
                        ?>

     <table class='table w-75 mx-auto table-bordered'>
          <thead class='table-light text-center'>
               <tr>

                     <th>Images</th>
                    <th>Nom</th>
                    <th>Prix</th>
                    
               </tr>
          </thead>
          <tbody>
                    
               <?php 
                       

                    $c= new mysqli("localhost","root","","db-ebook");
                    $sql = 'SELECT * FROM pannier';
                    $tab = $con->query($sql)->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($tab  as $row) {
                         echo $row['nom_pannier'];
                       
                         echo "<tr class=\"text-dark\">
                              <th >$row[0]</th>
                              <td>$row[2]</td>
                              <th style=\"font-size:13px\">$row[3]</th>
                              <th><a class=\"btn btn-danger\" href=\"\"> <i class=\"fa  fa-lg fa-trash\"  aria-hidden=\"true\"></i>   </a></th>



                         </tr>";

                    }
               
               ?>
               
          </tbody>
     </table>

     <br>

     
   
</body>
</html>