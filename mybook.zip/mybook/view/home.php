<!DOCTYPE html>
<html lang="fr">
<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!-- add icon link -->
      <link rel = "icon"  type = "##search">
                
     <title>ebookstore</title>
        <!--========== BOX ICONS ==========-->
        <link rel="stylesheet" href="view/css/boxicons.min.css">
       <!--========== CSS ==========-->
       <link rel="stylesheet" href="view/css/main.css">
       <!-- Google Fonts-->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Jomhuria&family=Work+Sans:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>

    <!-- Start Header -->
    <div class="header1" id="header1">
        <div class="container1">
            <a href="index.php" class="logo1"><img class="logo1" src="view/img/EbookStore.png"   alt="logowesite" >
            </a>
            <ul class="main-nav1">
                <li>
                    <a href="view/product/arabic.php">الكتب العربية</a>   
                 </li>
                 
                
                <li><a href="view/product/french.php">LIVRE FRANÇAIS</a>
                   
                </li>
                <li><a href="view/product/english.php">LIVRE ENGLAIS</a>
                   
                </li>
                <li><a href="product/nevau.html">NOUVEAUTÉS</a></li>
        </ul>
             <input class="sherche1" type="text" placeholder="Recherche...">
         <ul class="main-nav1">    
             <li><a href="?action=login"><i class='bx bx-user-circle bx-md'></i>Mon compte</a></li>
             <li>
                 <a href="#" class="cart1">
                   <i class='bx bx-basket bx-sm' ></i>
                  
                 </a>
             </li>
         </ul>
     </div>

 </div>
    <!-- End Header -->
    
    <!-- START SLIDER CARD -->
    
    <section class="product"> 
      <button class="pre-btn"><img src="view/img/arrow.png" alt=""></button>
      <button class="nxt-btn"><img src="view/img/arrow.png" alt=""></button>
      

      <div class="product-container">

                <?php
                        $con = conect();
                        $sql = 'SELECT * FROM livre where `théme` = 2022';
                        $tab = $con->query($sql)->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($tab  as $row) {

                        ?>
          <div class="product-card ">
              <div class="product-image">
                  <span class="discount-tag">50% off</span>
                  <img  src="view/image/<?= $row['image_livre'] ?>"  class="product-thumb" alt="">
                  <button class="card-btn">AJOUTER AU PANIER</button>
              </div>
              <div class="product-info ">
                  <h2 class="product-brand"> <?= $row['nom_livre'] ?></h2>
                  <span class="price"> <?= $row['prix_livre'] ?> DH </span></span>
              </div>
          </div>


          <?php
            }
                ?>

        </div>

      </div>
  </section>
  
  <script src="view/js/script.js"></script>

    <!-- END SLIDER CARD -->



  

       
   <!-- START CONTENT-->


   <!-- movies grid -->

   <div class="container mx-auto  ">

<h1 class=" text-secondary">Nouvelles</h1>


   <?php
            $con = conect();
            $sql = 'SELECT * FROM livre';
            $tab = $con->query($sql)->fetchAll(PDO::FETCH_ASSOC);
            foreach ($tab  as $row) {

            ?>


        <form action="" method="post" style="display:grid;
                        grid-row:1 ;
                        grid-template-columns: repeat(auto-fill,minmax(164px, 1fr));
                        gap:40px;
                        margin-bottom:10px;">
            <div class="card  rounded  row gy-2" class="col-md-4" style="width: 13rem; margin-left:258px; "> 


                <img class=" img-fluid" style="width: 100%; height: 20vw; object-fit: cover;" src="view/image/<?= $row['image_livre'] ?>" alt="" style="hight=80%">
                <div class="card-body   ">

                        <a href="#">
                            <p class="card-text fs-7 text-light "><?= $row['nom_livre'] ?></p>
                            <p class="card-text fs-7 text-light ">Prix: <?= $row['prix_livre'] ?> DH</p>
                            <p class="card-text fs-7 text-light ">By: <?= $row['editeur_livre'] ?></p>


                        </a>



                        <a href="#"><button type="button" class="btn d-flex justify-content-center text-light" > <i class='bx bx-plus'></i>View</button></a>
                </div>





            </div>

        <?php
    }
        ?>


        </form>



</div>


<!-- 
                    <div class="book-card">
              <div class="book-card__cover">
                <div class="book-card__book">
                  <div class="book-card__book-front">
                  </div>
                  <div class="book-card__book-back"></div>
                  <div class="book-card__book-side"></div>
                </div>
              </div>
              <div>
                <div class="book-card__title">
                       <a href="view/product/details.html">The Pragmatic Programmer </a>
                </div>
                <div class="book-card__author">
                    140,00 MAD
                </div>
                <div class="book-card__buttom">
                    <a href="#"> <button class="add-heart"><i class='bx bx-heart bx-sm' ></i> </button></a>
                    <a href="#"> <button class="add-basket"><i class='bx bx-basket bx-sm' ></i> AJOUTER AU PANIER</button> </a>
                </div>
              </div> -->
            </div>














                <?php
            
                ?>


                </form>



        </div>

            

            
          </main>

 <!-- END CONTENT -->



          <!-- STRAT FOOTER -->
          <div class="footer">
            <div class="container">
              <img  src="view/img/EbookStore.png" width="150px" alt="logowesite" >
              <p>Ebookstore de votre plus grande bibliothèque en ligne</p>
              <div class="social-icons">
                <a class="icon" href="view/home.php"><i class='bx bxs-home' ></i></a>
                <a class="icon" href="#"><i class='bx bxl-facebook-circle'></i></a>
                <a class="icon" href="#"><i class='bx bxl-twitter' ></i></a>
                <a class="icon" href="#"><i class='bx bxl-instagram-alt' ></i></a>
              </div>
              <p class="copyright">&copy; 2022 <span>ebookstore</span> All Right Reserved</p>

            </div>

          </div>




          <!-- END FOOTER -->
       

       

            



</body>
</html>