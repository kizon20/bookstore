<!DOCTYPE html>
<html lang="fr">
<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!-- add icon link -->
      <link rel = "icon"  type = "##search">
                
     <title>ebookstore</title>
        <link href="https://fonts.googleapis.com/css2?family=Jomhuria&family=Work+Sans:wght@300;400;700&display=swap" rel="stylesheet">
</head>
        <!--========== BOX ICONS ==========-->
        <link rel="stylesheet" href="view/css/boxicons.min.css">
       <!--========== CSS ==========-->
       <link rel="stylesheet" href="view/css/main.css">
       <!-- Google Fonts-->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<body>

    <!-- Start Header -->
    <div class="header1" id="header1">
        <div class="container1">
            <a href="index.php" class="logo1"><img class="logo1" src="view/img/EbookStore.png"   alt="logowesite" >
            </a>
            <ul class="main-nav1">
                <li>
                    <a href="view/product/arabic.html">الكتب العربية</a>   
                 </li>
                 
                
                <li><a href="view/product/french.html">LIVRE FRANÇAIS</a>
                   
                </li>
                <li><a href="view/product/english.html">LIVRE ENGLAIS</a>
                   
                </li>
                <li><a href="view/product/nevau.html">NOUVEAUTÉS</a></li>
            </ul>
                <input class="sherche1" type="text" placeholder="Recherche...">
            <ul class="main-nav1">    
                <li><a href="?action=logout"><i class='bx bx-log-in-circle bx-sm' ></i>Decconecxion</a></li>
                <li>
                    <?php
                    $con = conect();
                     $sql1 = 'SELECT count(*) FROM pannier';
                     $tabb = $con->query($sql1)->fetchAll();
                     
                     ?>
                    <a href="?action=pannier" class="cart1">
                      <i class='bx bx-basket bx-sm' ></i>
                    </a>
                </li>
            </ul>
        </div>

    </div>
    <!-- End Header -->
    
    <!-- START SLIDER CARD -->
    
    <section class="product"> 
      <button class="pre-btn"><img src="view/img/arrow.png" alt=""></button>
      <button class="nxt-btn"><img src="view/img/arrow.png" alt=""></button>
      <?php
                        $con = conect();
                        $sql = 'SELECT * FROM livre where `théme` = 2022';
                        $tab = $con->query($sql)->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($tab  as $row) {
                             ?>
      <div class="product-container">
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag">50% off</span>
                  <img  src="view/image/<?= $row['image_livre'] ?>" class="product-thumb" alt="">
                 <a href="?action=addP&id=<?=$row['id_livre']?>"> <button class="card-btn">AJOUTER AU PANIER</button> </a>
              </div>
        
              <div class="product-info">
                  <h2 class="product-brand"><?=$row['nom_livre']?>
                </h2>
                  <span class="price"><?=$row['prix_livre']?></span></span>
              </div>
          </div>
                     <?php
                       }?>
          <!-- <div class="product-card">
            <div class="product-image">
                <span class="discount-tag">50% off</span>
                <img src="view/img/book5.jpg" class="product-thumb" alt="">
                <button class="card-btn">AJOUTER AU PANIER</button>
            </div> -->
            <!-- <div class="product-info">
                <h2 class="product-brand">PHP & MySQL: Novice to Ninja</h2>
                <span class="price">210,00 DH</span>
            </div>
        </div>
         
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag">50% off</span>
                  <img src="view/img/book3.jpg" class="product-thumb" alt="">
                  <button class="card-btn">AJOUTER AU PANIER</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">الخيميائي </h2>
                  <span class="price">55.00 MAD</span>
              </div>
          </div>
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag">50% off</span>
                  <img src="view/img/book4.jpg" class="product-thumb" alt="">
                  <button class="card-btn">AJOUTER AU PANIER</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Effective Java</h2>
                  <span class="price">320,00 MAD</span>
              </div>
          </div>
          <div class="product-card">
            <div class="product-image">
                <span class="discount-tag">50% off</span>
                <img src="view/img/book2.jpg" class="product-thumb" alt="">
                <button class="card-btn">AJOUTER AU PANIER</button>
            </div>
            <div class="product-info">
                <h2 class="product-brand">The Little Prince</h2>
                <span class="price">55.00 DH</span>
            </div>
        </div>

          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag">50% off</span>
                  <img src="view/img/book6.jpg" class="product-thumb" alt="">
                  <button class="card-btn">AJOUTER AU PANIER</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Sleepwalk: A Novel</h2>
                  <span class="price">149.00 DH</span>
              </div>
          </div>
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag">50% off</span>
                  <img src="view/img/book7.jpg" class="product-thumb" alt="">
                  <button class="card-btn">AJOUTER AU PANIER</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Stolen Focus</h2>
                  <span class="price">95,00 DH</span>
              </div>
          </div>
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag">50% off</span>
                  <img src="view/img/book8.jpg" class="product-thumb" alt="">
                  <button class="card-btn">AJOUTER AU PANIER</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">فقه السيرة</h2>
                  <span class="price">145,00 DH</span>
              </div>
          </div>
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag">50% off</span>
                  <img src="view/img/book9.jpg" class="product-thumb" alt="">
                  <button class="card-btn">AJOUTER AU PANIER</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">Clean Code</h2>
                  <span class="price">425,00 DH</span>
              </div>
          </div>
          <div class="product-card">
              <div class="product-image">
                  <span class="discount-tag">50% off</span>
                  <img src="view/img/book10.jpg" class="product-thumb" alt="">
                  <button class="card-btn">AJOUTER AU PANIER</button>
              </div>
              <div class="product-info">
                  <h2 class="product-brand">JavaScript: The Definitive Guide</h2>
                  <span class="price">325,00 DH</span>
              </div>
          </div>
      </div> -->
  </section>
  
  <script src="view/js/script.js"></script>

    <!-- END SLIDER CARD -->



  

       
   <!-- START CONTENT-->

         <main>
          <h2 class="product-category">Meilleurs Vente</h2>
            <div class="book-card">
              <div class="book-card__cover">
                <div class="book-card__book">
                  <div class="book-card__book-front">
                   <a href="view/product/details.html"> <img class="book-card__img" src="view/img/tpp.jpg" /></a>
                  </div>
                  <div class="book-card__book-back"></div>
                  <div class="book-card__book-side"></div>
                </div>
              </div>
              <div>
                <div class="book-card__title">
                       <a href="view/product/details.html">The Pragmatic Programmer </a>
                </div>
                <div class="book-card__author">
                    140,00 MAD
                </div>
                <div class="book-card__buttom">
                    <a href="#"> <button class="add-heart"><i class='bx bx-heart bx-sm' ></i> </button></a>
                    <a href="#"> <button class="add-basket"><i class='bx bx-basket bx-sm' ></i> AJOUTER AU PANIER</button> </a>
                </div>
              </div>
            </div>


            <h2 class="product-category">Livres en vedette</h2>
            <div class="book-card">
              <div class="book-card__cover">
                <div class="book-card__book">
                  <div class="book-card__book-front">
                   <a href="view/product/details.html"> <img class="book-card__img" src="view/img/tpp.jpg" /></a>
                  </div>
                  <div class="book-card__book-back"></div>
                  <div class="book-card__book-side"></div>
                </div>
              </div>
              <div>
                <div class="book-card__title">
                       <a href="view/product/details.html">The Pragmatic Programmer </a>
                </div>
                <div class="book-card__author">
                    140,00 MAD
                </div>
                <div class="book-card__buttom">
                    <a href="#"> <button class="add-heart"><i class='bx bx-heart bx-sm' ></i> </button></a>
                    <a href="#"> <button class="add-basket"><i class='bx bx-basket bx-sm' ></i> AJOUTER AU PANIER</button> </a>
                </div>
              </div>
            </div>


            
            <h2 class="product-category">Nouveautéss</h2>
            <div class="book-card">
              <div class="book-card__cover">
                <div class="book-card__book">
                  <div class="book-card__book-front">
                   <a href="view/product/details.html"> <img class="book-card__img" src="view/img/tpp.jpg" /></a>
                  </div>
                  <div class="book-card__book-back"></div>
                  <div class="book-card__book-side"></div>
                </div>
              </div>
              <div>
                <div class="book-card__title">
                       <a href="view/product/details.html">The Pragmatic Programmer </a>
                </div>
                <div class="book-card__author">
                    140,00 MAD
                </div>
                <div class="book-card__buttom">
                    <a href="#"> <button class="add-heart"><i class='bx bx-heart bx-sm' ></i> </button></a>
                    <a href="#"> <button class="add-basket"><i class='bx bx-basket bx-sm' ></i> AJOUTER AU PANIER</button> </a>
                </div>
              </div>
            </div>


            
          </main>

 <!-- END CONTENT -->



          <!-- STRAT FOOTER -->
          <div class="footer">
            <div class="container">
              <img  src="view/img/EbookStore.png" width="150px" alt="logowesite" >
              <p>Ebookstore de votre plus grande bibliothèque en ligne</p>
              <div class="social-icons">
                <a class="icon" href="view/home.php"><i class='bx bxs-home' ></i></a>
                <a class="icon" href="#"><i class='bx bxl-facebook-circle'></i></a>
                <a class="icon" href="#"><i class='bx bxl-twitter' ></i></a>
                <a class="icon" href="#"><i class='bx bxl-instagram-alt' ></i></a>
              </div>
              <p class="copyright">&copy; 2022 <span>ebookstore</span> All Right Reserved</p>

            </div>

          </div>




          <!-- END FOOTER -->
       

       

            



</body>
</html>