<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Créer un nouveau compte client </title>
       <!--========== CSS ==========-->
     <link rel="stylesheet" href="view/css/login.css">
     <link rel="stylesheet" href="view/css/main.css">
     <!--========== BOX ICONS ==========-->
     <link rel="stylesheet" href="view/css/boxicons.min.css">
     <link rel="stylesheet" href="view/css/main.css">

</head>
<body>
        <!-- Start Header -->
  
<!-- End Header -->
<a href="?action=auth" class="logo1"><img class="logo1" src="view/img/EbookStore.png"   alt="logowesite" ></a>

     <h1>Créer un nouveau compte client</h1>
     <form action="?action=addUser" method="post">

        

     <div class="lgn">
         
          <ul>
               <!-- <li><label class="lb" for="">Prénom</label></li>
               <input class="inp" type="text" >
               <li><label class="lb" for="">Nom</label></li>
               <input class="inp" type="text" > -->
               <li><label class="lb" for="">Email</label></li>
               <input class="inp" name="email" type="text" >
               <li><label class="lb" for="">Mot de passe</label></li>
               <input class="inp" name="psw" type="text" >
               <li><label class="lb" for="">Confirmer le mot de passe  </label></li>
               <input class="inp" name="psw1" type="text" >
               
          </ul>
          <a href="#" class="link">Mot de passe oublié ?</a>
          
           <a href=""><button type="submit" name="regist" class="bt">CrÉer un compte</button></a>
     </div>
     </form>

</body>
</html>