<!DOCTYPE html>
<html lang="fr">
<head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Accès client</title>
        <!--========== CSS ==========-->
       
     <link rel="stylesheet" href="view/css/login.css">
     <link rel="stylesheet" href="view/css/main.css">

     <!--========== BOX ICONS ==========-->
     <link rel="stylesheet" href="view/css/boxicons.min.css">
</head>
<body>
   
 <!-- End Header -->
 <a href="?action=auth" class="logo1"><img class="logo1" src="view/img/EbookStore.png"   alt="logowesite" ></a>


     <h1>Accès client</h1>
     <div class="lgn">
          <h2>Clients enregistrés</h2>
          <form action="?action=auth" method="post">
          <ul>
               <li><label class="lb" for="">Email</label></li>
               <input class="inp" type="text" name="Email" >
               <li><label class="lb"  for="">Password</label></li>
               <input class="inp"  type="password" name="psw" >
               
          </ul>
           <button class="bt" type="submit" name="login" >Connexion</button>
           <a href="?action=register">  <input class="bt" type="button" value="Creer un compte" /></a>

     </div>
     </form>



     



        <!-- END FOOTER -->
     
</body>
</html>