<?php include_once('modele/conect.php');
session_start();
function login($u, $p)
{
    include_once('modele/conect.php');
    $con = conect();
    $req = "SELECT * from user  where login=:u and pwd=:p";
    $st = $con->prepare($req);
    $st->execute(['u' => $u, 'p' => $p]);
    $tabb = $st->fetchAll();
    //print_r($tab);
    if (count($tabb) == 0) {
        // unset($_SESSION["user"]);
        include_once('view/home.php');
    } elseif ($tabb[0][3] == 'user') {
        $req = "SELECT * from user where login=:u
                and pwd=:p ";
        $st = $con->prepare($req);
        $st->execute(['u' => $u, 'p' => $p]);
        $tab = $st->fetchAll();
        $_SESSION["id_user"] = $tab[0][0];
        $_SESSION["login"] = $tab[0][1];
        $_SESSION["pwd"] = $tab[0][2];
        $_SESSION['type'] = $tab[0][3];
        include_once('view/loginhom.php');
    } elseif ($tabb[0][3] == 'admin') {
        $_SESSION["id_user"] = $tab[0][0];
        $_SESSION["login"] = $tabb[0][1];
        $_SESSION["pwd"] = $tabb[0][2];
        $_SESSION['type'] = $tabb[0][3];
        include_once('view/admin.php');
    }
}
function logout()
{
    $_SESSION = array();
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
}

function newUser()
{
    if (isset($_POST['regist'])) {
        include_once('modele/conect.php');
        $u = $_POST['email'];
        $p = $_POST['psw'];
        $p1 = $_POST['psw1'];
        if ($p != $p1) {
            echo '<script>alert("VALID YOUR PASSWORD");</script>';
            return;
        } else {
            $con = conect();
            $sql = "INSERT INTO user (login,pwd,type) VALUES (?,?,?)";
            $stmt = $con->prepare($sql);
            $stmt->execute(array($u, $p,'user'));
        }
    }
}
function addlivre()
{
    if (isset($_POST['sub'])) {
        $from = $_FILES['image']['tmp_name'];
        $to = $_FILES['image']['name'];
        $mv =  move_uploaded_file($from, "view/image/" . $to);

        $title = $_POST['title'];
        $desc = $_POST['desc'];
        $isbn = $_POST['isbn'];
        $prix = $_POST['prix'];
        $qunty = $_POST['qunty'];
        $editeur = $_POST['editeur'];
        $date = $_POST['date'];
        $leng = $_POST['leng'];

        $img = $to;

        $con = conect();
        $sql = "INSERT INTO `livre` (`id_livre`, `nom_livre`, `editeur_livre`, `ISBN_livre`, `prix_livre`, `quantité_stock`, `image_livre`, `resume_livre`,`discipline`,`théme`) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?  );";
        $stmt = $con->prepare($sql);
        $stmt->execute(array(
            null, $title, $editeur, $isbn, $prix,  $qunty,  $to,  $desc, $leng,  $date
        ));
        echo '<script>alert("Film inserted successfully.");</script>';
    }
}

